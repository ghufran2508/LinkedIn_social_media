from classes import *;
from model import DbModel;


class DbHandler:
    def __init__(self, ip, user, password, database):
        self.model = DbModel(ip, user, password, database)

    def checkAdmin(self, email, password):
        member = Profile(email, password)

        AdminData = self.model.Adminlogin(member)

        if AdminData is not None:
            return AdminData
        else:
            return None

    def checklogin(self, email, password):
        member = Profile(email, password)

        memberData = self.model.login(member)

        if memberData is not None:
            return memberData
        else:
            return None

    def getAdminMembers(self):
        return self.model.AdminMembers()

    def deleteMember(self, id):
        self.model.deleteMemberRecord(id)

    def getPersonId(self,email):
        return self.model.getid(email)

    def signUp(self, email, password, first_name, last_name):
        return self.model.signup(email=email, password=password, first_name=first_name,last_name=last_name)

    def addAbout(self,About):
        return self.model.AddAbout(About)

    def modifyAbout(self,id,About):
        self.model.ModifyAbout(id,About)

    def getAbout(self,id):
        return self.model.getMemberAbout(id)

    def getMemberData(self, id):
        return self.model.getMember(id)

    def changebackground(self, id, filename):
        print("changing path of background")
        self.model.changeBg(id, filename)

    def changeDp(self, id, filename):
        print("changing path of background")
        self.model.changeDp(id, filename)

    def getBg(self,id):
        return self.model.getBgPath(id)

    def getDp(self,id):
        return self.model.getDpPath(id)

    def memberSearch(self, name):
        return self.model.getMembersSearch(name)

    def addToPending(self, sender_id, reciever_id):
        return self.model.addPendingRequest(sender_id, reciever_id)

    def getPending(self, rec_id):
        return self.model.getPendingRequests(rec_id)

    def clearFromPending(self, rec_id, send_id):
        return self.model.deletePending(rec_id,send_id)

    def AddFriend(self,friend1, friend2):
        self.model.addConnection(friend1,friend2)

    def getAllConnections(self,id):
        return self.model.getConnections(id)

    def createPost(self,id,text,image_path):
        memberData = self.model.getMember(id)
        name = memberData[0] + " " + memberData[1]
        self.model.savePost(id,name,text,image_path)

    def getmemberPosts(self,id):
        return self.model.getPosts(id)

    def addLike(self,post_id,friend_id,name,image):
        return self.model.addLike(post_id,friend_id,name,image)

    def dislike(self,post_id, friend_id):
        return self.model.disLike(post_id,friend_id)

    def addComment(self,post_id,friend_id,name,image,comment):
        return self.model.addComment(post_id,friend_id,name,image,comment)

    def getLikes(self, post_id):
        return self.model.getLikes(post_id)

    def getComments(self,post_id):
        return self.model.getComments(post_id)

    def getRoom(self,frnd1,frn2):
        return self.model.getRoomId(frnd1,frn2)

    def saveMessage(self,room_id,s_id,r_id,text):
        return self.model.AddMessage(room_id,s_id,r_id,text)

    def getOldMessages(self, room_id):
        return self.model.getAllMessages(room_id)