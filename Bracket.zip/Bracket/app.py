from werkzeug.utils import secure_filename

from dbHandler import *
import os
from flask import Flask, flash, render_template, request, redirect, session, jsonify
from flask_socketio import SocketIO, join_room, leave_room

app = Flask(__name__)
app.config.from_object("config")
app.secret_key = app.config["SECRET_KEY"]
db_ip = app.config["DB_IP"]
db_user = app.config["DB_USER"]
db_password = app.config["DB_PASSWORD"]
db_database = app.config["DB_DATABASE"]
app.config['UPLOAD_FOLDER'] = '/home/ghoofy/PycharmProjects/Bracket/static/images'
ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'])
socketio = SocketIO(app)

@app.route('/')
def hello_world():  # put application's code here
    return render_template('index.html')


@app.route('/about')
def about():
    return render_template('AboutForm.html')

# @app.route('/loading')
# def loading():
#     return render_template('loadingPage.html')


@app.route('/loading', methods=["POST"])
def getHome():
    email = request.form["email"]
    pwd = request.form["password"]

    handler = DbHandler(db_ip, db_user, db_password, db_database)
    result = handler.checklogin(email=email,password=pwd)

    if result is None:
        return render_template('index.html', error=True, errormsg="Email or Password is incorrect")

    session["email"] = email
    session["pwd"] = pwd
    session["id"] = result[0]
    return render_template('loadingPage.html')


@app.route('/forgot-password')
def forgotPassword():
    return render_template('forgot_password.html')


@app.route('/home')
def homePage():
    if "id" in session:
        handler = DbHandler(db_ip, db_user, db_password, db_database)
        memberdata = handler.getMemberData(session.get("id"))
        myAbout = handler.getAbout(session.get("id"))
        memberPost = handler.getmemberPosts(session.get("id"))

        return render_template('home.html', memberData=memberdata, myPosts=memberPost, myAbout=myAbout)
    else:
        return redirect('/')


@app.route('/signup')
def signUP():
    return render_template('signUp.html')


@app.route('/signedUpLoading', methods=["POST"])
def signedUp():
    first_name = request.form["first_name"]
    last_name = request.form["last_name"]
    email = request.form["email"]
    pwd = request.form["password"]
    cpwd = request.form["confirmpassword"]

    if len(pwd) < 8:
        return render_template('signUp.html', error=True, errormsg="Password length must be at least 8 characters")
    if pwd == cpwd:
        handler = DbHandler(db_ip, db_user, db_password, db_database)
        result = handler.signUp(email=email,password=pwd, first_name=first_name, last_name=last_name)

        if not result:
            return render_template('signUp.html', error=True, errormsg="Email Already Exist")
        else:
            session["email"] = email
            session["pwd"] = pwd
            session["id"] = handler.getPersonId(email)
            newMember = About(session.get("id"), '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
            handler.addAbout(newMember)

            return redirect('/my-about')
    else:
        return render_template('signUp.html', error=True, errormsg="Password Does not match")


@app.route('/my-about')
def AboutForm():
    if "id" in session:
        handler = DbHandler(db_ip,db_user,db_password,db_database)
        memberAbout = handler.getAbout(session.get("id"))
        return render_template('AboutForm.html', memberAbout=memberAbout)
    else:
        return redirect('/')


@app.route('/about-form', methods=["POST"])
def getAbout():
    if "id" in session:
        firstname = request.form["fname"]
        lastname = request.form["lname"]
        phone_number = request.form["phone"]
        address = request.form["address"]
        position = request.form["position"]
        exec_summary = request.form["executivesummary"]
        experience1 = request.form["experience1"]
        experience2 = request.form["experience2"]
        desc1 = request.form["description"]
        project_1 = request.form["project1"]
        project_2 = request.form["project2"]
        desc2 = request.form["description2"]
        skills = request.form["skills"]
        school = request.form["school"]
        degree = request.form["degree"]
        feild = request.form["field"]
        startDate = request.form["startdate"]
        endDate = request.form["enddate"]
        desc3 = request.form["description3"]

        myAbout = About(session.get("id"),firstname,lastname,phone_number,address,
                        position,exec_summary,experience1,experience2,
                        desc1,project_1,project_2,desc2,skills,
                        school,degree,feild,startDate,endDate,desc3
                        )
        handler = DbHandler(db_ip, db_user, db_password, db_database)
        handler.modifyAbout(session.get("id"),myAbout)

        return redirect('/home')
    else:
        return redirect('/')


@app.route('/resume')
def buildResume():
    handler = DbHandler(db_ip,db_user,db_password,db_database)
    memberData = handler.getMemberData(session.get("id"))
    memberAbout = handler.getAbout(session.get("id"))
    skills = []
    skills = memberAbout[13].split(' ')

    return render_template('resume.html', memberData=memberData,memberAbout=memberAbout,skills=skills)


@app.route('/uploadBackground', methods=["POST", "GET"])
def uploadBg():
    if "id" in session:
        if request.method == 'POST':
            # check if the post request has the file part
            print(request.files)
            if 'file1' not in request.files:
                flash('No file part')
                return redirect('/home')
            file = request.files['file1']
            # if user does not select file, browser also
            # submit a empty part without filename
            if file.filename == '':
                flash('No selected file')
                return redirect(request.url)
            if file:
                # filename = secure_filename(file.filename)

                handler = DbHandler(db_ip, db_user, db_password, db_database)
                prev = handler.getBg(session.get("id"))[0]
                print(prev)
                prev = prev.split("/")[-1]

                if prev != "linkedin-default-background.png":
                    os.remove(os.path.join(app.config["UPLOAD_FOLDER"], prev))

                filename = str(session.get("id")) + "-background." + file.filename.split(".")[-1]
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                handler.changebackground(session.get("id"), filename)

        return redirect('/home')
    else:
        return redirect('/')


@app.route('/uploadDp', methods=["POST", "GET"])
def uploadDp():
    if "id" in session:
        if request.method == 'POST':
            # check if the post request has the file part
            print(request.files)
            if 'file2' not in request.files:
                flash('No file part')
                return redirect('/home')
            file = request.files['file2']
            # if user does not select file, browser also
            # submit a empty part without filename
            if file.filename == '':
                flash('No selected file')
                return redirect(request.url)
            if file:
                # filename = secure_filename(file.filename)

                handler = DbHandler(db_ip, db_user, db_password, db_database)
                prev = handler.getDp(session.get("id"))[0]
                prev = prev.split("/")[-1]

                if prev != "default.jpg":
                    os.remove(os.path.join(app.config["UPLOAD_FOLDER"], prev))

                filename = str(session.get("id")) + "-dp." + file.filename.split(".")[-1]
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                handler.changeDp(session.get("id"),filename)

        return redirect('/home')
    else:
        return redirect('/')


@app.route('/searchResult', methods=["GET", "POST"])
def getResult():
    if "id" in session:
        handler = DbHandler(db_ip, db_user, db_password, db_database)
        name = str(request.args["searchquery"])
        result = []
        myId = session.get("id")
        resultTuple = handler.memberSearch(name=name)
        for searches in resultTuple:
            if searches[4] != myId:
                result.append(searches)
        friendsArray = handler.getAllConnections(session.get("id"))

        friendsId = []
        for friends in friendsArray:
            if friends[1] == myId:
                friendsId.append(friends[2])
            else:
                friendsId.append(friends[1])

        return render_template('search.html', membersArray=result, friendsArray=friendsId)
    else:
        return redirect('/')


@app.route('/request', methods=["GET","POST"])
def sentRequest():
    if "id" in session:
        handler = DbHandler(db_ip, db_user, db_password, db_database)
        friend_id = int(request.args["id"])

        handler.addToPending(session.get("id"), friend_id)

        return render_template('RequestSent.html')
    else:
        return redirect('/')


@app.route('/notifications')
def notifcations():
    if "id" in session:
        handler = DbHandler(db_ip, db_user, db_password, db_database)
        allPendings = handler.getPending(session.get("id"))
        memberData = []
        for senders in allPendings:
            memberData.append(handler.getMemberData(senders[1]))

        return render_template('Pendings.html', membersArray=memberData)
    else:
        return redirect('/')


@app.route('/acceptReject', methods=["POST"])
def acceptorreject():
    if "id" in session:
        handler = DbHandler(db_ip, db_user, db_password, db_database)
        friend_id = request.form["id"]
        accept = True
        try:
            if request.form["Accept"] == "Accept":
                accept = True
        except:
            if request.form["Reject"] == "Reject":
                accept = False

        handler.clearFromPending(session.get("id"), friend_id)
        if accept:
            handler.AddFriend(session.get("id"), friend_id)

        return redirect('/home')
    else:
        return redirect('/')


@app.route('/connections')
def getConnections():
    if "id" in session:
        handler = DbHandler(db_ip, db_user, db_password, db_database)
        friendsArray = []
        myId = session.get("id")
        allFriendsid = handler.getAllConnections(session.get("id"))
        for membertuples in allFriendsid:
            if membertuples[1] != myId:
                friendsArray.append(handler.getMemberData(membertuples[1]))
            else:
                friendsArray.append(handler.getMemberData(membertuples[2]))

        return render_template('connections.html', membersArray=friendsArray)
    else:
        return redirect('/')


@app.route('/create-post')
def createPsot():
    if "id" in session:
        return render_template('createPost.html')
    else:
        return redirect('/')


@app.route('/upload-post', methods=["POST"])
def uploadPost():
    if "id" in session:
        if request.method == 'POST':
            print(request.form)
            text = request.form["comment"]
            imagepath = ''
            # check if the post request has the file part
            print(request.files)
            if 'image' not in request.files:
                imagepath = ''
            else:
                file = request.files['image']
                # if user does not select file, browser also
                # submit a empty part without filename
                if file.filename == '':
                    imagepath = ''
                else:
                    if file:
                        # filename = secure_filename(file.filename)
                        imagepath = secure_filename(file.filename)
                        file.save(os.path.join(app.config['UPLOAD_FOLDER']+"/post", file.filename))


        if text != '' or imagepath != '':
            handler = DbHandler(db_ip,db_user,db_password,db_database)
            handler.createPost(session.get("id"),text,imagepath)

        return redirect('/home')
    else:
        return redirect('/')


@app.route('/newsfeed')
def newsFeed():
    if "id" in session:
        handler = DbHandler(db_ip,db_user,db_password,db_database)
        friendsArray = []
        myId = session.get("id")
        allFriendsid = handler.getAllConnections(session.get("id"))
        for membertuples in allFriendsid:
            if membertuples[1] != myId:
                friendsArray.append(handler.getMemberData(membertuples[1]))
            else:
                friendsArray.append(handler.getMemberData(membertuples[2]))

        friendsPosts = []
        for friends in friendsArray:
            data = handler.getmemberPosts(friends[4])
            if len(data) >= 1:
                friendsPosts.append(data)

        comments = []
        likes = []
        for posts in friendsPosts:
            comments.append(handler.getComments(posts[0][5]))
            likes.append(handler.getLikes(posts[0][5]))

        print(likes)

        myData = handler.getMemberData(myId)

        return render_template('NewsFeed.html', Posts=friendsPosts, membersArray=friendsArray, length=len(friendsArray), myData=myData, likes=likes, comments=comments, zip=zip)
    else:
        return redirect('/')


@app.route('/addLike', methods=["POST"])
def addLike():
    post_id = request.form["id"]
    friend_id = request.form["friend_id"]
    name = request.form["name"]
    image_path = request.form["image"]

    handler = DbHandler(db_ip, db_user,db_password,db_database)
    handler.addLike(post_id,friend_id,name,image_path)
    return "Liked"


@app.route('/disLike', methods=["POST"])
def disLike():
    post_id = request.form["id"]
    friend_id = request.form["friend_id"]

    handler = DbHandler(db_ip, db_user,db_password,db_database)
    handler.dislike(post_id,friend_id)
    return "Disliked"


@app.route('/addComment', methods=["POST"])
def addComment():
    post_id = request.form["id"]
    friend_id = request.form["friend_id"]
    name = request.form["name"]
    image_path = request.form["image"]
    comment = request.form["comment"]

    handler = DbHandler(db_ip, db_user, db_password, db_database)
    handler.addComment(post_id,friend_id,name,image_path,comment)

    return "Comment Added"


@app.route('/logout')
def logout():
    if "id" in session:
        session.clear()
    return redirect('/')


@app.route('/admins')
def Admin():
    return render_template('AdmiLogin.html')


@app.route('/AdminLogin', methods=["POST"])
def checkAdmin():
    handler = DbHandler(db_ip,db_user,db_password,db_database)
    email = request.form["email"]
    pwd = request.form["password"]

    result = handler.checkAdmin(email,pwd)

    if result is None:
        return render_template('AdmiLogin.html', error=True, errormsg="Email or Password is incorrect")
    else:
        return render_template('MemberTable.html')


@app.route('/modify-member', methods=["POST"])
def membercheck():
    if "delete" in request.form:
        person_id = request.form["delete"]
        handler = DbHandler(db_ip, db_user,db_password,db_database)
        handler.deleteMember(person_id)

        return render_template('MemberTable.html')

    if "view-profile" in request.form:
        person_id = request.form["view-profile"]
        handler = DbHandler(db_ip, db_user, db_password, db_database)
        memberdata = handler.getMemberData(person_id)
        myAbout = handler.getAbout(person_id)
        memberPost = handler.getmemberPosts(person_id)

        return render_template('MemberView.html', memberData=memberdata, myPosts=memberPost, myAbout=myAbout)


@app.route('/membersprivateData', methods=["GET"])
def getPrivateData():
    handler = DbHandler(db_ip,db_user,db_password,db_database)
    membersData = handler.getAdminMembers()

    return jsonify(membersData)


@app.route('/chat', methods=["POST","GET"])
def chat():
    if "id" in session:
        friend_id = int(request.form["id"])
        my_id = int(session.get("id"))

        handler = DbHandler(db_ip, db_user, db_password, db_database)
        myData = handler.getMemberData(my_id)
        friendData = handler.getMemberData(friend_id)
        room = handler.getRoom(my_id,friend_id)[0]
        messages = handler.getOldMessages(room)
        allChats = []
        if messages is not None:
            for message in messages:
                allChats.append(message)
        return render_template('Chat.html', myData=myData, friendData=friendData, room=room, oldchat=allChats)
    else:
        return redirect('/')


@socketio.on('send_message')
def handle_send_message_event(data):
    app.logger.info("{} has sent message to the room {}: {}".format(data['friend_id'],
                                                                    data['name'],
                                                                    data['room'],
                                                                    data['message']))

    chatHandler = DbHandler(db_ip,db_user,db_password,db_database)
    chatHandler.saveMessage(data['room'],int(session.get("id")),int(data['friend_id']), data['message'])

    socketio.emit('receive_message', data, room=data['room'])


@socketio.on('join_room')
def handle_join_room_event(data):
    app.logger.info("{} has joined the room {}".format(data['name'], data['room']))
    join_room(data['room'])
    socketio.emit('join_room_announcement', data, room=data['room'])


@socketio.on('leave_room')
def handle_leave_room_event(data):
    app.logger.info("{} has left the room {}".format(data['name'], data['room']))
    leave_room(data['room'])
    socketio.emit('leave_room_announcement', data, room=data['room'])

# @app.route('/rooms/messages/', methods=["GET"])
# def get_older_messages():
#     # room = get_room(room_id)
#     # if room and is_room_member(room_id, current_user.username):
#     #     page = int(request.args.get('page', 0))
#     #     messages = get_messages(room_id, page)
#
#     chatHandler = DbHandler(db_ip,db_user,db_password,db_database)
#     messages = chatHandler.getAllMessages(1)
#     return jsonify(messages)

if __name__ == '__main__':
    socketio.run(app)
