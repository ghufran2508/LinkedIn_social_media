class Profile:
    def __init__(self, email, password):
        self.email = email
        self.password = password

class About:
    def __init__(self,id,fname,lname,phone,address,position,exec_summ,exp1,exp2,desc1,pro1,pro2,desc2,skills,school,degree,feild,sdate,edate,desc3):
        self.id = id
        self.fname = fname
        self.lname = lname
        self.phone = phone
        self.address=address
        self.position = position
        self.exec_summ = exec_summ
        self.exp1 = exp1
        self.exp2 = exp2
        self.desc1 = desc1
        self.project1 = pro1
        self.project2 = pro2
        self.desc2 = desc2
        self.skills = skills
        self.school=school
        self.degree = degree
        self.feild = feild
        self.sdate = sdate
        self.edate = edate
        self.desc3 = desc3