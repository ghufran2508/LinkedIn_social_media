import pymysql


class DbModel:
    def __init__(self, localhost, user, password, database):
        self.connection = None

        try:
            self.connection = pymysql.connect(
                host=localhost,
                user=user,
                password=password,
                database=database
            )
        except Exception as e:
            print(str(e))
            self.connection = None

    def __del__(self):
        if self.connection is not None:
            self.connection.close()

    def Adminlogin(self, Profile):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()
                query = "Select * from admin where email=%s and password=%s"
                args = (Profile.email, Profile.password)

                exist = cursor.execute(query, args)
                if exist == 1:
                    result = cursor.fetchone()

                    cursor.close()
                    return result
                else:
                    return None
            except Exception as e:
                print(str(e))

    def AdminMembers(self):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                cursor.execute("select * from profiles")
                rows = cursor.fetchall()

                cursor.close()

                AllProfiles = []
                for profiles in rows:
                    member = []
                    member.append(profiles[0])
                    member.append(profiles[1])
                    member.append(profiles[2])
                    member.append(profiles[0])
                    member.append(profiles[0])

                    AllProfiles.append(member)

                return AllProfiles
            except Exception as e:
                print(str(e))
                return None
        else:
            return None

    def deleteMemberRecord(self,id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                cursor.execute("delete from member where id=%s",id)
                cursor.execute("delete from pending where reciever_id=%s or sender_id=%s", (id,id))
                cursor.execute("delete from post_likes where friend_id=%s", id)
                cursor.execute("delete from post_comments where friend_id=%s", id)
                cursor.execute("delete from posts where id=%s", id)
                cursor.execute("delete from connections where friend1=%s or friend2=%s", (id, id))
                cursor.execute("delete from chat_history where sender_id=%s or reciever_id=%s", (id,id))
                cursor.execute("delete from resume where id=%s", id)
                cursor.execute("delete from profiles where id=%s", id)

                self.connection.commit()

                cursor.close()
            except Exception as e:
                print(str(e))


    def login(self, Profile):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()
                query = "Select * from profiles where email=%s and password=%s"
                args = (Profile.email, Profile.password)

                exist = cursor.execute(query, args)
                if exist == 1:
                    result = cursor.fetchone()

                    cursor.close()
                    return result
                else:
                    return None
            except Exception as e:
                print(str(e))

    def getid(self, email):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                exist = cursor.execute("select id from profiles where email=%s",email)
                if exist == 1:
                    id = cursor.fetchone()
                else:
                    return -1

                cursor.close()

                return id
            except Exception as e:
                print(str(e))
                return -1
        else:
            return -1

    def __AlreadyExist__(self, email):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()
                query = "select * from profiles where email=%s"
                arg=email

                cursor.execute(query,arg)
                result = cursor.fetchone()

                cursor.close()

                if result is None:
                    return False
                else:
                    return True

            except Exception as e:
                print(str(e))
                return True
        else:
            return True

    def __getID__(self,email):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "select id from profiles where email=%s"
                arg=email

                cursor.execute(query, arg)
                result = cursor.fetchone()

                cursor.close()
                if result is not None:
                    return result
                else:
                    return -1
            except Exception as e:
                print(str(e))
                return -1
        else:
            return -1

    def signup(self, email, password, first_name, last_name):
        if self.connection is not None:
            exist = self.__AlreadyExist__(email)
            if not exist:
                try:
                    cursor = self.connection.cursor()

                    query = "insert into profiles(email, password) value(%s,%s)"
                    args = (email, password)

                    cursor.execute(query, args)

                    self.connection.commit()

                    dp = "images/default.jpg"
                    background = "images/linkedin-default-background.png"
                    id = self.__getID__(email)

                    query = "insert into member(first_name,last_name,email,password,dp,background,id) value(%s,%s,%s,%s,%s,%s,%s)"
                    args = (first_name, last_name, email,password,dp,background,id)

                    cursor.execute(query, args)

                    self.connection.commit()

                    cursor.close()
                    return True
                except Exception as e:
                    print((str(e)))
                    return False
            else:
                return False
        else:
            return False

    def ModifyAbout(self,id,About):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "update resume set firstname=%s,lastname=%s,phone=%s,address=%s," \
                        "position=%s,executivessummary=%s,experience1=%s,experience2=%s," \
                        "description=%s,project1=%s,project2=%s,description2=%s," \
                        "skils=%s,school=%s,degree=%s,feildofstudy=%s," \
                        "startDate=%s,endDate=%s,description3=%s where id=%s"
                arg = (About.fname, About.lname, About.phone, About.address, About.position,
                       About.exec_summ, About.exp1, About.exp2, About.desc1, About.project1, About.project2,
                       About.desc2, About.skills, About.school, About.degree, About.feild,
                       About.sdate, About.edate, About.desc3, id)

                cursor.execute(query,arg)
                self.connection.commit()

                cursor.close()
            except Exception as e:
                print(str(e))
                return False
        else:
            return False

    def AddAbout(self,About):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query="insert into resume values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                arg=(About.id,About.fname,About.lname,About.phone,About.address,About.position,
                     About.exec_summ,About.exp1,About.exp2,About.desc1,About.project1,About.project2,About.desc2,
                     About.skills,About.school,About.degree,About.feild,About.sdate,About.edate,About.desc3)

                cursor.execute(query,arg)

                self.connection.commit()

                cursor.close()

                return True
            except Exception as e:
                return False
        else:
            return False

    def getMemberAbout(self,id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "select * from resume where id=%s"
                arg=(id)

                cursor.execute(query,arg)
                result = cursor.fetchone()

                cursor.close()

                return result
            except Exception as e:
                print(str(e))
                return False
        else:
            return None

    def getMember(self,id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                cursor.execute("select * from member where id=%s",id)
                result = cursor.fetchone()

                cursor.close()

                return result
            except Exception as e:
                print(str(e))
        else:
            return None

    def changeBg(self, id, filename):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                path = "images/"+filename
                query="update member set background=%s where id=%s"
                args=(path,id)

                cursor.execute(query,args)
                self.connection.commit()

                cursor.close()
                return True
            except Exception as e:
                print(str(e))
                return False
        else:
            return False

    def changeDp(self, id, filename):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                path = "images/"+filename
                query="update member set dp=%s where id=%s"
                args=(path,id)

                cursor.execute(query,args)
                self.connection.commit()

                cursor.close()
                return True
            except Exception as e:
                print(str(e))
                return False
        else:
            return False

    def getBgPath(self, id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                cursor.execute("select background from member where id=%s",id)

                path = cursor.fetchone()

                cursor.close()

                return path
            except Exception as e:
                print(str(e))
                return None
        else:
            return None

    def getDpPath(self, id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                cursor.execute("select dp from member where id=%s",id)

                path = cursor.fetchone()

                cursor.close()

                return path
            except Exception as e:
                print(str(e))
                return None
        else:
            return None

    def getMembersSearch(self, name):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "Select * from member where first_name like %s or last_name like %s or email=%s"
                args=(name,name,name)
                cursor.execute(query, args)

                result = cursor.fetchall()

                cursor.close()
                return result
            except Exception as e:
                print(str(e))
                return None
        else:
            return None

    def __AlreadyPending__(self, sender_id, reciever_id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "select * from pending where sender_id=%s and reciever_id=%s"
                args=(sender_id, reciever_id)

                cursor.execute(query,args)
                result = cursor.fetchone()

                cursor.close()

                if result is None:
                    return False
                else:
                    return True
            except Exception as e:
                print(str(e))
                return True
        else:
            return True

    def addPendingRequest(self, sender_id, reciever_id):
        if self.connection is not None:
            if self.__AlreadyPending__(sender_id, reciever_id):
                return False
            else:
                try:
                    cursor = self.connection.cursor()

                    query = "insert into pending(sender_id,reciever_id) values(%s,%s)"
                    args=(sender_id, reciever_id)

                    cursor.execute(query,args)
                    self.connection.commit()

                    cursor.close()

                    return True
                except Exception as e:
                    print(str(e))
                    return False
        else:
            return False

    def getPendingRequests(self, id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "select * from pending where reciever_id=%s"
                arg=(id)

                cursor.execute(query, arg)
                result = cursor.fetchall()
                cursor.close()

                return result
            except Exception as e:
                print(str(e))
                return None
        else:
            return None

    def deletePending(self, rec_id, sen_id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "delete from pending where reciever_id=%s and sender_id=%s"
                args=(rec_id,sen_id)
                cursor.execute(query,args)

                self.connection.commit()

                cursor.close()
                return True
            except Exception as e:
                print(str(e))
                return False
        else:
            return False

    def __AlreadyConnected__(self,friend1, friend2):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "select * from connections where friend1=%s and friend2=%s"
                args=(friend1,friend2)
                cursor.execute(query,args)

                result = cursor.fetchone()

                cursor.close()
                if result is None:
                    return False
                else:
                    return True
            except Exception as e:
                print(str(e))
                return True
        else:
            return True

    def addConnection(self,friend1, friend2):
        if self.connection is not None:
            try:
                if self.__AlreadyConnected__(friend1,friend2):
                    return
                cursor = self.connection.cursor()

                query = "insert into connections(friend1, friend2) values(%s,%s)"
                args=(friend1,friend2)
                cursor.execute(query,args)
                self.connection.commit()

                cursor.close()
            except Exception as e:
                print(str(e))

    def getConnections(self,id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "select * from connections where friend1=%s or friend2=%s"
                args=(id,id)
                cursor.execute(query,args)

                result = cursor.fetchall()

                cursor.close()

                return result
            except Exception as e:
                print(str(e))
                return None
        else:
            return None

    def savePost(self, id, name, text, image_path):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                path = "images/post/" + image_path
                query = "insert into posts(id,name,time_upload,text_description,image_path) values (%s,%s,now(), %s,%s)"
                args=(id,name,text,path)

                cursor.execute(query,args)
                self.connection.commit()

                cursor.close()
                return True
            except Exception as e:
                print(str(e))
                return False
        else:
            return False


    def getPosts(self, id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "select * from posts where id=%s order by time_upload DESC"
                arg=(id)

                cursor.execute(query,id)

                result = cursor.fetchall()
                cursor.close()

                return result
            except Exception as e:
                print(str(e))
                return None
        else:
            return None

    def __alreadyLike__(self,post_id, friend_id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "select * from post_likes where post_id=%s and friend_id=%s"
                arg=(post_id,friend_id)

                cursor.execute(query,arg)
                result = cursor.fetchone()

                cursor.close()

                if result is None:
                    return False
                else:
                    return True
            except Exception as e:
                print(str(e))
                return True
        else:
            return True

    def addLike(self, post_id, friend_id, name, image):
        if self.connection is not None:
            try:
                if self.__alreadyLike__(post_id, friend_id):
                    return
                cursor = self.connection.cursor()

                query = "insert into post_likes(post_id,friend_id,name,image_path) value(%s,%s,%s,%s)"
                args=(post_id,friend_id,name,image)

                cursor.execute(query,args)

                self.connection.commit()
                cursor.close()
                return True
            except Exception as e:
                print(str(e))
                return False
        else:
            return False

    def disLike(self, post_id, friend_id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "delete from post_likes where post_id=%s and friend_id=%s"
                args=(post_id,friend_id)

                cursor.execute(query,args)

                self.connection.commit()
                cursor.close()
                return True
            except Exception as e:
                print(str(e))
                return False
        else:
            return False

    def getLikes(self, post_id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()
                cursor.execute("select post_id,friend_id from post_likes where post_id=%s", (post_id))
                cursor.execute("select post_id,friend_id from post_likes where post_id=%s", (post_id))

                result = cursor.fetchall()
                cursor.close()

                return result
            except Exception as e:
                print(str(e))
                return 0
        else:
            return 0

    def getComments(self, post_id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                cursor.execute("select * from post_comments where post_id=%s",(post_id))

                result = cursor.fetchall()
                cursor.close()

                return result
            except Exception as e:
                print(str(e))
                return None
        else:
            return None

    def addComment(self, post_id, friend_id, name, image, comment):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "insert into post_comments(post_id,friend_id,name,image_path,comment) value(%s,%s,%s,%s,%s)"
                args=(post_id,friend_id,name,image,comment)

                cursor.execute(query,args)

                self.connection.commit()
                cursor.close()
                return True
            except Exception as e:
                print(str(e))
                return False
        else:
            return False

    def getRoomId(self, frnd1, frnd2):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "select room_id from connections where (friend1=%s and friend2=%s) or (friend1=%s and friend2=%s)"
                args=(frnd1,frnd2,frnd2,frnd1)

                cursor.execute(query,args)
                result = cursor.fetchone()

                cursor.close()

                return result
            except Exception as e:
                print(str(e))
                return False
        else:
            return False

    def AddMessage(self, room_id, sender_id, reciever_id, text):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "insert into chat_history(room_id, sender_id, reciever_id,text,time_send) values(%s,%s,%s,%s,now())"
                args = (room_id, sender_id, reciever_id, text)

                cursor.execute(query, args)
                self.connection.commit()

                cursor.close()
            except Exception as e:
                print(str(e))
                return False
        else:
            print("database not connected....")
            return False

    def getAllMessages(self, room_id):
        if self.connection is not None:
            try:
                cursor = self.connection.cursor()

                query = "Select * from chat_history where room_id=%s"
                args = (room_id)

                cursor.execute(query, args)
                result = cursor.fetchall()
                cursor.close()

                return result
            except Exception as e:
                print(str(e))
                return None
        else:
            print("database not connected....")
            return None





        # if self.connection is not None:
        #     try:
        #         cursor = self.connection.cursor()
        #
        #         query = ""
        #
        #         cursor.close()
        #     except Exception as e:
        #         print(str(e))
        #         return False
        # else:
        #     return False