import pymysql

def getDpPath():
    try:
        connection = pymysql.connect(
            host="localhost",
            user="root",
            password="root",
            database="web_eng"
        )
        cursor = connection.cursor()

        cursor.execute("Select path from images where id=1")
        path = cursor.fetchone()

        cursor.close()
        connection.close()

        return path
    except Exception as e:
        print(str(e))
        return ""